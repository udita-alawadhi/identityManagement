package com.cg.ibs.bean;

public enum AccountType {
	INDIVIDUAL, JOINT
}
