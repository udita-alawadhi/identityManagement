package com.cg.ibs.im.ui;

public enum BankerAction {
	VIEW_PENDING_DETAILS, VIEW_APPROVED_DETAILS, VIEW_DENIED_DETAILS, GO_BACK
}
