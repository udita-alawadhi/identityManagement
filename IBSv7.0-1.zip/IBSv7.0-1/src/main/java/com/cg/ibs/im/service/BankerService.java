package com.cg.ibs.im.service;

import java.util.Set;

import com.cg.ibs.im.model.ApplicantBean;
import com.cg.ibs.im.model.CustomerBean;
import com.cg.ibs.im.exception.IBSCustomException;

public interface BankerService {
	
	boolean verifyBankerLogin(String user, String password) throws IBSCustomException;
	
	Set<ApplicantBean> viewPendingApplications() throws IBSCustomException;
	
	Set<ApplicantBean> viewApprovedApplications() throws IBSCustomException;
	
	Set<ApplicantBean> viewDeniedApplications() throws IBSCustomException;
	
	boolean updateCustomer(CustomerBean customer) throws IBSCustomException;
	
	String generatePassword(long applicantId);
	
	CustomerBean createNewCustomer(ApplicantBean applicant) throws IBSCustomException;

	boolean isApplicantPresentInPendingList(long applicantId) throws IBSCustomException;

	boolean isApplicantPresent(long applicantId) throws IBSCustomException;

	ApplicantBean displayDetails(long applicantId) throws IBSCustomException;

	String generateUsername(long applicantId) throws IBSCustomException;

	boolean download(ApplicantBean applicant) throws IBSCustomException;
}
