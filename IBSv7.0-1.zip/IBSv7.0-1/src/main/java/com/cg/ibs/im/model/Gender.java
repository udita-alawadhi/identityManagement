package com.cg.ibs.im.model;

public enum Gender {
	PREFER_NOT_TO_SAY, MALE, FEMALE;
}
