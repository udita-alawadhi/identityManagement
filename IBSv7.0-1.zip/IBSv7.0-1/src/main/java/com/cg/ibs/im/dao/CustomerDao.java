package com.cg.ibs.im.dao;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.im.model.CustomerBean;
import com.cg.ibs.im.exception.IBSCustomException;

public interface CustomerDao {
	
	
	boolean saveCustomer(CustomerBean customer) throws IBSCustomException;
	
	CustomerBean getCustomerDetails(String uci) throws IBSCustomException;
	
	Set<BigInteger> getAllCustomers() throws IBSCustomException;

	CustomerBean getCustomerByApplicantId(Long applicantId) throws IBSCustomException;

	boolean checkCustomerByUsernameExists(String username) throws IBSCustomException;

	boolean checkCustomerExists(BigInteger uci) throws IBSCustomException;

	boolean updateCustomer(CustomerBean customer) throws IBSCustomException;
}
